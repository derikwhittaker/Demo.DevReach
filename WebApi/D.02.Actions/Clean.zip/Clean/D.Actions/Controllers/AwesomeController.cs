﻿using System.Web.Http;

namespace D.Actions.Controllers
{
    public class AwesomeController : ApiController
    {

    }

}