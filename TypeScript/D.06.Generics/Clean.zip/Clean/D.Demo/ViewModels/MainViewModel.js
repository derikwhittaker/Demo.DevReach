/// <reference path="../Scripts/typings/knockout/knockout.d.ts" />
var DevReach;
(function (DevReach) {
    var MainViewModel = (function () {
        function MainViewModel() {
        }
        MainViewModel.prototype.run = function () {
        };
        return MainViewModel;
    })();
    DevReach.MainViewModel = MainViewModel;
})(DevReach || (DevReach = {}));
