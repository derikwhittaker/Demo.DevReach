/// <reference path="../Scripts/typings/knockout/knockout.d.ts" />

module DevReach {


    export class MainViewModel {


        public run() {

        }
    }

}